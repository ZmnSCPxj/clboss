#ifndef BOSS_RANDOM_ENGINE_HPP
#define BOSS_RANDOM_ENGINE_HPP

#include<random>

namespace Boss {

extern std::default_random_engine random_engine;

}

#endif /* !defined(BOSS_RANDOM_ENGINE_HPP) */
