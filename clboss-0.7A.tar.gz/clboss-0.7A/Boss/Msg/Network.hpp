#ifndef BOSS_MSG_NETWORK_HPP
#define BOSS_MSG_NETWORK_HPP

namespace Boss { namespace Msg {

enum Network
{ Network_Bitcoin
, Network_Testnet
, Network_Regtest
};

} }

#endif /* !defined(BOSS_MSG_NETWORK_HPP) */
