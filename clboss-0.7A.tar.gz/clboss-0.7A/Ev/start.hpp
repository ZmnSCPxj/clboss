#ifndef EV_START_HPP
#define EV_START_HPP

namespace Ev { template<typename a> class Io; }

namespace Ev {

int start(Ev::Io<int>);

}

#endif /* EV_START_HPP */
