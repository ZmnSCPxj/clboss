#ifndef BOSS_MSG_BEGIN_HPP
#define BOSS_MSG_BEGIN_HPP

namespace Boss { namespace Msg {

/** struct Boss::Msg::Begin
 *
 * @brief message broadcasted at the start of the system.
 */
struct Begin {
};

}}

#endif /* !defined(BOSS_MSG_BEGIN_HPP) */
