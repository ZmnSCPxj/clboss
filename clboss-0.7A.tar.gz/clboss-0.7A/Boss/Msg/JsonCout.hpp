#ifndef BOSS_MSG_JSONCOUT_HPP
#define BOSS_MSG_JSONCOUT_HPP

#include"Json/Out.hpp"

namespace Boss { namespace Msg {

struct JsonCout {
	Json::Out obj;
};

}}

#endif /* !defined(BOSS_MSG_JSONCOUT_HPP) */
