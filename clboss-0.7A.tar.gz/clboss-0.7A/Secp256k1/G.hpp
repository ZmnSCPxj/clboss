#ifndef SECP256K1_G_HPP
#define SECP256K1_G_HPP

namespace Secp256k1 { class PubKey; }
namespace Secp256k1 { extern PubKey G; }

#endif /* SECP256K1_G_HPP */
