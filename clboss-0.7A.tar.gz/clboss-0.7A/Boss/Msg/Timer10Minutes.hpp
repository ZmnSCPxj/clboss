#ifndef BOSS_MSG_TIMER10MINUTES_HPP
#define BOSS_MSG_TIMER10MINUTES_HPP

namespace Boss { namespace Msg {

/** struct Boss::Msg::Timer10Minutes
 *
 * @brief emitted every 10 minutes.
 */
struct Timer10Minutes { };

}}

#endif /* !defined(BOSS_MSG_TIMER10MINUTES_HPP) */
