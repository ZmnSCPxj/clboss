#ifndef BOSS_MSG_JSONCIN_HPP
#define BOSS_MSG_JSONCIN_HPP

#include"Jsmn/Object.hpp"

namespace Boss { namespace Msg {

struct JsonCin {
	Jsmn::Object obj;
};

}}

#endif /* !defined(BOSS_MSG_JSONCIN_HPP */

